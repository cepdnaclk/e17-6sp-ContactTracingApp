import React, { useState } from 'react';

export const AuthContext = React.createContext();